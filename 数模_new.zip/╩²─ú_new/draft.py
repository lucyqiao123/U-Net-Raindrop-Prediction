import torch
import numpy as np
import torch.nn as nn
from torchvision import datasets
from torchvision import transforms
import torch.nn.functional as F
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
from torch. nn import functional as F
from visdom import Visdom
from visdom import Visdom
import matplotlib.pyplot as plt
import torch
from torch.distributions import MultivariateNormal as MVN
from torch import nn

a=torch.randn((4,10,32,32))
b=torch.randn((4,10,32,32))
c = F.interpolate(b, scale_factor=0.25)
print(c.shape)
noise_var=torch.tensor(8.0)
def draw(frames_true,frames_pred): #test画图部分
    # 绘制前10帧和后10帧的图片
    num_rows = 4
    num_cols = 5
    num_images = num_rows * num_cols
    sample_true=frames_true[-1] #[4,10,256,256]-->[10,256,256]
    sample_pred=frames_pred[-1]


    plt.figure(figsize=(12, 10))
    for i in range(num_images):
        plt.subplot(num_rows, num_cols, i + 1)
        if i < 10:
            plt.imshow(sample_true[i], cmap='coolwarm')  # 更改cmap以使用不同的颜色图
            plt.title(f'Frame {i + 1} (True)')
        else:
            plt.imshow(sample_pred[i - 10], cmap='coolwarm')  # 更改cmap以使用不同的颜色图
            plt.title(f'Frame {i - 9} (Pred)')
        plt.axis('off')
    plt.tight_layout()
    plt.show()

draw(b,c)
# def reshape_for_bmc_loss(pred, target):
#     batch_size = pred.size(0)
#     pred = pred.view(batch_size, -1)
#     target = target.view(batch_size, -1)
#     return pred, target
# def bmc_loss_md(pred, target, noise_var):
#     pred, target = reshape_for_bmc_loss(pred, target)
#     I_diag = torch.ones(pred.shape[-1])
#     I_diag = I_diag.to(pred.device) # [4,1,256*256*10] [256*256*10,256*256*10]
#     logits = MVN(pred.unsqueeze(1), noise_var * torch.diag(I_diag)).log_prob(target.unsqueeze(0))  # logit size: [batch, batch]
#     loss = F.cross_entropy(logits, torch.arange(pred.shape[0]))  # contrastive-like loss
#     loss = loss * (2 * noise_var).detach()  # optional: restore the loss scale, 'detach' when noise is learnable
#     return loss
# bmc_loss_md(a,b,noise_var)